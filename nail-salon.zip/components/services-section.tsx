import Image from "next/image"

export function ServicesSection() {
  return (
    <section id="services" className="bg-[#f5d7d7] py-20">
      <div className="container mx-auto px-6">
        <div className="text-center space-y-6 mb-16">
          <p className="text-[#8B4049] font-serif text-2xl italic">Our services</p>
          <h2 className="text-5xl lg:text-6xl font-serif text-[#2c3e50]">FEATURED NAIL SERVICES</h2>
          <p className="text-xl text-[#2c3e50]">All kinds of procedures for your hands and feet.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="relative h-[400px] overflow-hidden">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-T0TM0eQf0CXXcgPNdxeBzBdOQLntbn.png"
              alt="Manicure service"
              fill
              className="object-cover hover:scale-105 transition-transform duration-300"
            />
          </div>
          <div className="relative h-[400px] overflow-hidden">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-T0TM0eQf0CXXcgPNdxeBzBdOQLntbn.png"
              alt="Nail art service"
              fill
              className="object-cover hover:scale-105 transition-transform duration-300"
            />
          </div>
          <div className="relative h-[400px] overflow-hidden">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-T0TM0eQf0CXXcgPNdxeBzBdOQLntbn.png"
              alt="Pedicure service"
              fill
              className="object-cover hover:scale-105 transition-transform duration-300"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
