import Link from "next/link"

const features = [
  {
    icon: (
      <svg viewBox="0 0 100 100" className="w-16 h-16">
        <rect x="20" y="30" width="8" height="50" fill="#8B4049" rx="2" />
        <rect x="35" y="20" width="8" height="60" fill="#8B4049" rx="2" />
        <rect x="50" y="25" width="8" height="55" fill="#8B4049" rx="2" />
        <ellipse cx="50" cy="15" rx="25" ry="8" fill="none" stroke="#8B4049" strokeWidth="3" />
      </svg>
    ),
    title: "Sterile Tools",
    description: "We have one-use files and dry-heat sterilizers.",
  },
  {
    icon: (
      <svg viewBox="0 0 100 100" className="w-16 h-16">
        <ellipse cx="50" cy="35" rx="18" ry="22" fill="#8B4049" />
        <path d="M 32 55 Q 50 65 68 55" fill="#8B4049" />
        <circle cx="50" cy="70" r="8" fill="#8B4049" />
        <rect x="45" y="75" width="10" height="15" fill="#8B4049" />
      </svg>
    ),
    title: "Expert Staff",
    description: "Our nail masters work fast and safely.",
  },
  {
    icon: (
      <svg viewBox="0 0 100 100" className="w-16 h-16">
        <circle cx="30" cy="30" r="8" fill="#8B4049" />
        <circle cx="50" cy="30" r="8" fill="#8B4049" />
        <circle cx="70" cy="30" r="8" fill="#8B4049" />
        <circle cx="30" cy="50" r="8" fill="#8B4049" />
        <circle cx="50" cy="50" r="8" fill="#8B4049" />
        <circle cx="70" cy="50" r="8" fill="#8B4049" />
        <circle cx="30" cy="70" r="8" fill="#8B4049" />
        <circle cx="50" cy="70" r="8" fill="#8B4049" />
        <circle cx="70" cy="70" r="8" fill="#8B4049" />
      </svg>
    ),
    title: "100+ Colors",
    description: "You can choose any nail polish you like.",
  },
  {
    icon: (
      <svg viewBox="0 0 100 100" className="w-16 h-16">
        <rect x="25" y="20" width="50" height="60" rx="5" fill="none" stroke="#8B4049" strokeWidth="3" />
        <rect x="35" y="35" width="30" height="8" fill="#8B4049" />
        <rect x="35" y="50" width="30" height="8" fill="#8B4049" />
        <rect x="35" y="65" width="30" height="8" fill="#8B4049" />
      </svg>
    ),
    title: "Famous Brands",
    description: "Our partners are Luxio, OPI, Essie, etc.",
  },
]

export function FeaturesSection() {
  return (
    <section className="bg-[#f5d7d7] py-20">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {features.map((feature, index) => (
            <div key={index} className="flex flex-col items-start space-y-4">
              <div className="text-[#8B4049]">{feature.icon}</div>
              <h3 className="text-2xl font-serif text-[#2c3e50]">{feature.title}</h3>
              <p className="text-[#2c3e50] leading-relaxed">{feature.description}</p>
              <Link
                href="#"
                className="text-[#8B4049] font-bold uppercase text-sm tracking-wider hover:underline border-b-2 border-[#8B4049] pb-1"
              >
                MORE INFO
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
