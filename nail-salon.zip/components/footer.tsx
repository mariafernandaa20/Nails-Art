import { Facebook, Instagram, Twitter, Youtube } from "lucide-react"
import Link from "next/link"

export function Footer() {
  return (
    <footer className="bg-[#3d4557] py-16">
      <div className="container mx-auto px-6">
        <div className="flex flex-col items-center space-y-8">
          {/* Left Text */}
          <p className="text-white/80 text-lg">Nail care you deserve.</p>

          {/* Center Logo and Navigation */}
          <div className="flex flex-col items-center space-y-6">
            <Link href="/" className="flex items-center gap-3">
              <div className="w-12 h-12 relative">
                <svg viewBox="0 0 50 50" className="w-full h-full">
                  <rect x="15" y="10" width="3" height="15" fill="white" rx="1.5" />
                  <rect x="23" y="10" width="3" height="15" fill="white" rx="1.5" />
                  <rect x="31" y="10" width="3" height="15" fill="white" rx="1.5" />
                  <path d="M12 30 L18 35 L18 40 L12 38 Z" fill="white" />
                  <path d="M20 30 L26 35 L26 40 L20 38 Z" fill="white" />
                  <path d="M28 30 L34 35 L34 40 L28 38 Z" fill="white" />
                  <path d="M36 30 L42 35 L42 40 L36 38 Z" fill="white" />
                  <ellipse cx="25" cy="28" rx="18" ry="6" fill="none" stroke="white" strokeWidth="2" />
                </svg>
              </div>
              <h2 className="text-3xl font-serif text-white tracking-wide">Lotus</h2>
            </Link>

            <nav className="flex flex-wrap items-center justify-center gap-8">
              <Link href="#services" className="text-white/80 hover:text-white transition-colors">
                Services
              </Link>
              <Link href="#about" className="text-white/80 hover:text-white transition-colors">
                About
              </Link>
              <Link href="#manicure" className="text-white/80 hover:text-white transition-colors">
                Manicure
              </Link>
              <Link href="#pedicure" className="text-white/80 hover:text-white transition-colors">
                Pedicure
              </Link>
              <Link href="#testimonials" className="text-white/80 hover:text-white transition-colors">
                Testimonials
              </Link>
              <Link href="#contacts" className="text-white/80 hover:text-white transition-colors">
                Contacts
              </Link>
            </nav>
          </div>

          {/* Right Social Icons */}
          <div className="flex items-center gap-3">
            <Link
              href="#"
              className="w-10 h-10 bg-transparent border border-white/30 hover:bg-white/10 transition-colors flex items-center justify-center"
              aria-label="Facebook"
            >
              <Facebook className="w-5 h-5 text-white" />
            </Link>
            <Link
              href="#"
              className="w-10 h-10 bg-transparent border border-white/30 hover:bg-white/10 transition-colors flex items-center justify-center"
              aria-label="Instagram"
            >
              <Instagram className="w-5 h-5 text-white" />
            </Link>
            <Link
              href="#"
              className="w-10 h-10 bg-transparent border border-white/30 hover:bg-white/10 transition-colors flex items-center justify-center"
              aria-label="Twitter"
            >
              <Twitter className="w-5 h-5 text-white" />
            </Link>
            <Link
              href="#"
              className="w-10 h-10 bg-transparent border border-white/30 hover:bg-white/10 transition-colors flex items-center justify-center"
              aria-label="YouTube"
            >
              <Youtube className="w-5 h-5 text-white" />
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
