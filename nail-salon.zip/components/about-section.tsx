import { Button } from "@/components/ui/button"
import { Phone } from "lucide-react"
import Image from "next/image"

export function AboutSection() {
  return (
    <section id="about" className="bg-[#f5d7d7] py-20">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Image */}
          <div className="relative h-[600px]">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-Sl8tmad7g0G1uNF6VVOXRcDyTcALrz.png"
              alt="Professional nail artist at work"
              fill
              className="object-cover"
            />
          </div>

          {/* Right Content */}
          <div className="space-y-8">
            <p className="text-[#8B4049] font-serif text-2xl italic">About us</p>

            <h2 className="text-5xl lg:text-6xl font-serif text-[#2c3e50] leading-tight">WELCOME TO LOTUS!</h2>

            <p className="text-lg text-[#2c3e50] leading-relaxed">
              Lotus is a perfect place to get high-quality nail care and spa services in a clean and welcoming
              atmosphere.
            </p>

            <p className="text-lg text-[#2c3e50] leading-relaxed">
              Our licensed nail artists are always aware of the latest trends and truly care about their clients. We
              also offer free Wi-Fi, relaxing music, and complimentary cookies and beverages to make your experience
              more enjoyable.
            </p>

            <div className="flex items-center gap-4 pt-4">
              <div className="w-12 h-12 bg-[#8B4049] rounded-full flex items-center justify-center">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-[#8B4049] font-medium">Call us now!</p>
                <p className="text-2xl font-serif text-[#8B4049]">+1 (234) 567 89 00</p>
              </div>
            </div>

            <Button size="lg" className="bg-[#8B4049] hover:bg-[#6d3238] text-white px-8 py-6 text-lg font-medium">
              More About Us
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
