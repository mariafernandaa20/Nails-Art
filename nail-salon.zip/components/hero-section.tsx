import { Button } from "@/components/ui/button"
import Image from "next/image"

export function HeroSection() {
  return (
    <section className="min-h-screen bg-[#f5d7d7] pt-24">
      <div className="container mx-auto px-6 py-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-[calc(100vh-12rem)]">
          {/* Left Content */}
          <div className="space-y-8">
            <p className="text-[#8B4049] font-serif text-2xl italic">Nail care</p>

            <h2 className="text-6xl lg:text-7xl font-serif text-[#2c3e50] leading-tight">
              ENJOY THE BEST
              <br />
              NAIL CARE IN NY
            </h2>

            <p className="text-xl text-[#2c3e50] font-medium">Make your nails perfect right now!</p>

            <Button size="lg" className="bg-[#8B4049] hover:bg-[#6d3238] text-white px-8 py-6 text-lg font-medium">
              Book an Appointment
            </Button>
          </div>

          {/* Right Image */}
          <div className="relative h-[600px] lg:h-[700px]">
            <Image
              src="/elegant-woman-with-perfect-manicured-nails-touchin.jpg"
              alt="Professional nail care"
              fill
              className="object-cover"
              priority
            />
          </div>
        </div>
      </div>
    </section>
  )
}
