import Image from "next/image"

const pricingItems = [
  {
    name: "Buff manicure",
    description: "Well-groomed nails without any polish.",
    price: "$12",
  },
  {
    name: "Glue manicure",
    description: "Long-lasting manicure with resin glue acting as a base coat.",
    price: "$20",
  },
  {
    name: "CND Shellac or OPI Gel manicure",
    description: "Long-lasting manicure with gel nail polish.",
    price: "$25",
  },
  {
    name: "French manicure",
    description: "Light pink or nude nail beds with bold white nail tips.",
    price: "$55",
  },
  {
    name: "Gel off manicure",
    description: "Gel polish removal and nail care.",
    price: "$35",
  },
]

export function PricingSection() {
  return (
    <section id="manicure" className="bg-[#f5d7d7] py-20">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Image */}
          <div className="relative h-[700px]">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-VYkfIPcXFAnZjCcV3mREcYxHh7IfAb.png"
              alt="Beautiful manicured hands with flowers"
              fill
              className="object-cover"
            />
          </div>

          {/* Right Content */}
          <div className="space-y-8">
            <p className="text-[#8B4049] font-serif text-2xl italic">Pricing</p>

            <h2 className="text-5xl lg:text-6xl font-serif text-[#2c3e50] leading-tight">PRICING FOR MANICURE</h2>

            <p className="text-lg text-[#2c3e50] leading-relaxed">
              We believe that your perfect nails are the result of the continuous search for excellence and attention to
              details.
            </p>

            <div className="space-y-6 pt-4">
              {pricingItems.map((item, index) => (
                <div key={index} className="border-b border-[#2c3e50]/20 pb-6">
                  <div className="flex items-start justify-between gap-4 mb-2">
                    <h3 className="text-2xl font-serif text-[#2c3e50]">{item.name}</h3>
                    <span className="text-2xl font-serif text-[#8B4049] whitespace-nowrap">{item.price}</span>
                  </div>
                  <p className="text-[#2c3e50]">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
