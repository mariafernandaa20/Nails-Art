import { Facebook, Instagram, Twitter, Youtube } from "lucide-react"
import Link from "next/link"

export function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#f5d7d7]/95 backdrop-blur-sm">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3">
            <div className="w-12 h-12 relative">
              <svg viewBox="0 0 50 50" className="w-full h-full">
                <rect x="15" y="10" width="3" height="15" fill="#8B4049" rx="1.5" />
                <rect x="23" y="10" width="3" height="15" fill="#8B4049" rx="1.5" />
                <rect x="31" y="10" width="3" height="15" fill="#8B4049" rx="1.5" />
                <path d="M12 30 L18 35 L18 40 L12 38 Z" fill="#8B4049" />
                <path d="M20 30 L26 35 L26 40 L20 38 Z" fill="#8B4049" />
                <path d="M28 30 L34 35 L34 40 L28 38 Z" fill="#8B4049" />
                <path d="M36 30 L42 35 L42 40 L36 38 Z" fill="#8B4049" />
                <ellipse cx="25" cy="28" rx="18" ry="6" fill="none" stroke="#8B4049" strokeWidth="2" />
              </svg>
            </div>
            <div>
              <h1 className="text-3xl font-serif text-[#2c3e50] tracking-wide">Lotus</h1>
              <p className="text-xs text-[#2c3e50]/70 tracking-widest uppercase">Nail Care in NY</p>
            </div>
          </Link>

          {/* Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            <Link href="#services" className="text-[#2c3e50] hover:text-[#8B4049] transition-colors font-medium">
              Services
            </Link>
            <Link href="#about" className="text-[#2c3e50] hover:text-[#8B4049] transition-colors font-medium">
              About
            </Link>
            <Link href="#manicure" className="text-[#2c3e50] hover:text-[#8B4049] transition-colors font-medium">
              Manicure
            </Link>
            <Link href="#pedicure" className="text-[#2c3e50] hover:text-[#8B4049] transition-colors font-medium">
              Pedicure
            </Link>
            <Link href="#testimonials" className="text-[#2c3e50] hover:text-[#8B4049] transition-colors font-medium">
              Testimonials
            </Link>
            <Link href="#contacts" className="text-[#2c3e50] hover:text-[#8B4049] transition-colors font-medium">
              Contacts
            </Link>
          </nav>

          {/* Social Icons */}
          <div className="flex items-center gap-3">
            <Link
              href="#"
              className="w-10 h-10 bg-[#2c3e50] hover:bg-[#8B4049] transition-colors flex items-center justify-center"
              aria-label="Facebook"
            >
              <Facebook className="w-5 h-5 text-white" />
            </Link>
            <Link
              href="#"
              className="w-10 h-10 bg-[#2c3e50] hover:bg-[#8B4049] transition-colors flex items-center justify-center"
              aria-label="Instagram"
            >
              <Instagram className="w-5 h-5 text-white" />
            </Link>
            <Link
              href="#"
              className="w-10 h-10 bg-[#2c3e50] hover:bg-[#8B4049] transition-colors flex items-center justify-center"
              aria-label="Twitter"
            >
              <Twitter className="w-5 h-5 text-white" />
            </Link>
            <Link
              href="#"
              className="w-10 h-10 bg-[#2c3e50] hover:bg-[#8B4049] transition-colors flex items-center justify-center"
              aria-label="YouTube"
            >
              <Youtube className="w-5 h-5 text-white" />
            </Link>
          </div>
        </div>
      </div>
    </header>
  )
}
